@echo off
chcp 65001 >nul 2>&1
title 中国时序地图 - ChronoMap CN

echo ╔══════════════════════════════════════╗
echo ║   中国时序地图 · ChronoMap CN        ║
echo ║   正在启动开发服务器...              ║
echo ╚══════════════════════════════════════╝
echo.

cd /d "%~dp0"

:: 检查 node_modules 是否存在
if not exist "node_modules" (
  echo [1/3] 首次运行，正在安装依赖...
  call npm install
  if errorlevel 1 (
    echo.
    echo ❌ 依赖安装失败，请确保已安装 Node.js 18+
    pause
    exit /b 1
  )
  echo.
)

:: 启动开发服务器
echo [2/3] 启动开发服务器...
echo.
call npm run dev
