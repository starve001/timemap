// ── 朝代 ──
export interface Dynasty {
  id: string;
  name: string;
  startYear: number;   // 负数 = 公元前
  endYear: number;
  color: string;
  capital: string;
  capitalCoords: [number, number]; // [lng, lat]
  description?: string;
}

// ── 历史事件 ──
export interface HistoryEvent {
  id: string;
  title: string;
  description: string;
  startYear: number;
  endYear?: number;
  location: [number, number]; // [lng, lat]
  locationName: string;
  dynastyId: string;
  category: 'war' | 'politics' | 'culture' | 'economy' | 'technology';
  importance: 1 | 2 | 3 | 4 | 5;
  personIds?: string[];
}

// ── 历史人物 ──
export interface Person {
  id: string;
  name: string;
  courtesyName?: string;  // 字
  birthYear?: number;
  deathYear?: number;
  birthPlace?: [number, number];
  birthPlaceName?: string;
  dynastyId: string;
  biography?: string;
  avatarUrl?: string;
}

// ── 人物关系 ──
export interface PersonRelation {
  personA: string; // person id
  personB: string;
  relation: 'father' | 'son' | 'mother' | 'daughter' | 'ruler' | 'minister' | 'teacher' | 'student' | 'friend' | 'enemy' | 'spouse' | 'sibling';
  description?: string;
}

// ── GeoJSON 类型（与 MapLibre 兼容） ──
import type { FeatureCollection } from 'geojson';
export type GeoJSONCollection = FeatureCollection;

// ── 疆域 ──
export interface Territory {
  dynastyId: string;
  year?: number; // 某一年，undefined = 整个朝代
  geojson: GeoJSONCollection;
}

// ── 地图状态 ──
export interface MapState {
  center: [number, number];
  zoom: number;
  currentDynastyId: string;
  selectedEventId?: string;
  compareMode: boolean;
  compareDynastyId?: string;
}

// ── 时间轴状态 ──
export interface TimelineState {
  rangeStart: number;
  rangeEnd: number;
  cursorYear: number;
  zoomLevel: 'dynasty' | 'century' | 'decade' | 'year';
}
